package com.example.assignment2;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class LocationAdapter extends ArrayAdapter<LocationModel> {

    private List<LocationModel> locationModels;
    private LayoutInflater inflater;

    public LocationAdapter(Context context, List<LocationModel> locationModels) {
        super(context, 0, locationModels);
        //Only set to 50 items
        if (locationModels.size() > 50) {
            this.locationModels = locationModels.subList(0, 50);
        } else {
            this.locationModels = locationModels;
        }

        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = inflater.inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        TextView addressTextView = view.findViewById(android.R.id.text1);
        TextView latAndLongView = view.findViewById(android.R.id.text2);

        //Get the LocationModel for this position
        LocationModel locationModel = getItem(position);

        addressTextView.setText(locationModel.getAddress());
        String latLong = "Lat: " + locationModel.getLat() + ", Long: " + locationModel.getLongitude();
        latAndLongView.setText(latLong);

        return view;
    }
}
