package com.example.assignment2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "location";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "locationTable";
    private static final String ID_COL = "id";
    private static final String ADDRESS_COL = "address";
    private static final String LAT_COL = "latitude";
    private static final String LONG_COL = "longitude";
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME); // Drop the table if it already exists

        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ADDRESS_COL + " TEXT,"
                + LAT_COL + " DOUBLE,"
                + LONG_COL + " DOUBLE)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //Method to add a new location to database
    public boolean addNewLocation(LocationModel locationModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ADDRESS_COL, locationModel.getAddress());
        values.put(LAT_COL, locationModel.getLat());
        values.put(LONG_COL, locationModel.getLongitude());

        long insert = db.insert(TABLE_NAME, null, values);
        return insert != -1;
    }

    //Update row function
    public boolean updateLocation(LocationModel locationModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ADDRESS_COL, locationModel.getAddress());
        values.put(LAT_COL, locationModel.getLat());
        values.put(LONG_COL, locationModel.getLongitude());

        int updatedRows = db.update(TABLE_NAME, values, ID_COL + " = ?", new String[]{String.valueOf(locationModel.getId())});
        Log.d("UpdateLocation", "Updated " + updatedRows + " rows");
        return updatedRows > 0;
    }

    //Delete row method
    public boolean deleteOne(LocationModel locationModel){
        SQLiteDatabase db = this.getWritableDatabase();

        String queryString = ID_COL + " = ?";
        Log.d("DeleteQuery", queryString);
        int deletedRows = db.delete(TABLE_NAME, queryString, new String[]{String.valueOf(locationModel.getId())});
        Log.d("DeletedRows", String.valueOf(deletedRows));

        return deletedRows > 0;
    }

    //Get all in database
    public List<LocationModel> getAll(){
        List<LocationModel> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            do{
                int locationId = cursor.getInt(0);
                String locationAddress = cursor.getString(1);
                double locationLat = cursor.getDouble(2);
                double locationLong = cursor.getDouble(3);

                LocationModel newNote = new LocationModel(locationId, locationAddress, locationLat, locationLong);
                returnList.add(newNote);

            }while(cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return returnList;
    }
}
