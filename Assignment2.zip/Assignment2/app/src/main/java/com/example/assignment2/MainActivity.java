package com.example.assignment2;
import androidx.appcompat.app.AppCompatActivity;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private DBHandler dbHandler;
    private ListView locationsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Intialization
        List<Double> latitudes = new ArrayList<>();
        List<Double> longitudes = new ArrayList<>();
        locationsList = findViewById(R.id.list);
        SearchView searchbar = findViewById(R.id.search);
        Button add = findViewById(R.id.addLocation);
        dbHandler = new DBHandler(this);
        dbHandler.onUpgrade(dbHandler.getWritableDatabase(), 1, 2);

        List<LocationModel> locationModels = dbHandler.getAll();
        List<String> locationAddresses = new ArrayList<>();
        for (LocationModel note : locationModels) {
            locationAddresses.add(note.getAddress());
        }

        //Read input from raw file lat_and_long, and store lat and long into seperate variables
        try {
            InputStream raw = getResources().openRawResource(R.raw.lat_and_long);
            BufferedReader in = new BufferedReader(new InputStreamReader(raw));

            String line;
            while ((line = in.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length == 2) {
                    double latitude = Double.parseDouble(parts[0]);
                    double longitude = Double.parseDouble(parts[1]);

                    latitudes.add(latitude);
                    longitudes.add(longitude);
                }
            }

            in.close();
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }

        //Use reverse geocoding to get address from lat and long
        if (Geocoder.isPresent()) {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());

            for (int i = 0; i < latitudes.size(); i++) {
                double latitude = latitudes.get(i);
                double longitude = longitudes.get(i);

                try {
                    List<Address> ls = geocoder.getFromLocation(latitude, longitude, 1);
                    for (Address addr: ls) {
                        String address = addr.getAddressLine(0);
                        Log.d("AddressDetails", "Address: " + address);

                        //Insert address, lat, and long to database
                        LocationModel location = new LocationModel(-1, address, latitude, longitude);
                        boolean isInserted = dbHandler.addNewLocation(location);

                        //Error checking
                        if (isInserted) {
                            Log.d("Database", "Location added to the database, ID: " + location.getId());
                        } else {
                            Log.d("Database", "Failed to add location to the database");
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        LocationAdapter locationsAdapter = new LocationAdapter(MainActivity.this, dbHandler.getAll());
        locationsList.setAdapter(locationsAdapter);

        //Search bar function to search for specific address
        searchbar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            //Allows search bar to match address of items in list
            public boolean onQueryTextChange(String newText) {
                newText = newText.toLowerCase();
                List<LocationModel> filteredList = new ArrayList<>();
                for (LocationModel location : dbHandler.getAll()) {
                    if (location.getAddress().toLowerCase().contains(newText)) {
                        filteredList.add(location);
                    }
                }
                locationsAdapter.clear();
                locationsAdapter.addAll(filteredList);
                return true;
            }
        });

        //Method to delete item from list when it is pressed down
        locationsList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                LocationModel clickedLocation = (LocationModel) parent.getItemAtPosition(position);
                if (clickedLocation != null) {
                    boolean isDeleted = dbHandler.deleteOne(clickedLocation);

                    if (isDeleted) {
                        //Remove the item from the list and update list
                        locationsAdapter.remove(clickedLocation);
                        locationsAdapter.notifyDataSetChanged();
                    }
                }
                return true;
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText addressField = findViewById(R.id.addLocationField);
                String address = addressField.getText().toString();

                if (!address.isEmpty()) {
                    if (Geocoder.isPresent()) {
                        //Get address' lat and long using geocoding, and store into variables
                        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
                        try {
                            List<Address> addresses = geocoder.getFromLocationName(address, 1);
                            if (!addresses.isEmpty()) {
                                Address addr = addresses.get(0); // Assuming you want the first result

                                double latitude = addr.getLatitude();
                                double longitude = addr.getLongitude();

                                LocationModel locationModel = new LocationModel(-1, address, latitude, longitude);
                                boolean success = dbHandler.addNewLocation(locationModel);

                                if (success) {
                                    //Clear the input field
                                    addressField.setText("");

                                    //Update the list
                                    List<LocationModel> updatedList = dbHandler.getAll();
                                    locationsAdapter.clear();
                                    locationsAdapter.addAll(updatedList);
                                    locationsAdapter.notifyDataSetChanged();

                                    Toast.makeText(MainActivity.this, "Location Added", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(MainActivity.this, "Address not found", Toast.LENGTH_SHORT).show();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please enter an address", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Method to allow users to click specific item on list to update it
        locationsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                LocationModel clickedLocation = (LocationModel) parent.getItemAtPosition(position);

                EditText editAddress = findViewById(R.id.updateLocationField);
                editAddress.setText(clickedLocation.getAddress());
                Button updateButton = findViewById(R.id.updateLocationButton);

                //Method to update address when button is clicked on
                updateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String newAddress = editAddress.getText().toString();
                        if (!newAddress.isEmpty()) {
                            clickedLocation.setAddress(newAddress);
                            boolean isUpdated = dbHandler.updateLocation(clickedLocation);

                            if (isUpdated) {
                                //Update list
                                locationsAdapter.notifyDataSetChanged();
                                Toast.makeText(MainActivity.this, "Location Updated", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "Please enter an address", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}