package com.example.assignment2;

public class LocationModel {
    private int id;
    private String address;
    private double lat;
    private double longitude;

    public LocationModel(int id, String address, double lat, double longitude){
        this.id = id;
        this.address = address;
        this.lat = lat;
        this.longitude = longitude;
    }

    public LocationModel(){

    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getAddress(){
        return address;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public double getLat(){
        return lat;
    }

    public void setLat(double lat){
        this.lat = lat;
    }

    public double getLongitude(){
        return longitude;
    }

    public void setLongitude(double longitude){
        this.longitude = longitude;
    }

}
